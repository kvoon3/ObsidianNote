# Styling the Backlinks

Here is an example task block that does not hide any components of the output.

It shows that the the backlink (the file and heading names) can quite dominate the results.

```tasks
not done
description includes trash
```
