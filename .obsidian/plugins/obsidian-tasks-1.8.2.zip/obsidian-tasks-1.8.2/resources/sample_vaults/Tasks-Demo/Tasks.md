# Tasks

## All

```tasks
```

## Open tasks from Important Project

```tasks
not done
path includes Important Project
```

## Due before 6th of December

```tasks
not done
due before 2021-12-06
```

## Short Mode

```tasks
not done
due before 2021-12-06
short mode
```

## No match

```tasks
not done
done after 2021-11-21
```
