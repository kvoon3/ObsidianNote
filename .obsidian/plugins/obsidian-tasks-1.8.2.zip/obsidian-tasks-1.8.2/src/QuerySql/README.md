# Query SQL

This folder contains the Query SQL class and related data services. Future work will be adding the code and updating this file with the context of each class in this space.
