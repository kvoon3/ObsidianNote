module.exports = {
  trailingComma: 'all',
  singleQuote: true,
  tabWidth: 4,
};
